﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace KnockoutGame
{
    public partial class HomeScreen : Form
    {
        public HomeScreen()
        {
            InitializeComponent();
        }

        private void PlayButton_Click(object sender, EventArgs e)
        {
            GameScreen gs = new GameScreen();
            this.Hide();
            gs.Show();
        }

        private void ScoreButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            HighScoreScreen hss = new HighScoreScreen();
            hss.Show();
        }
    }
}
