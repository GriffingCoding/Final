﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace KnockoutGame
{
    public partial class GameScreen : Form
    {
        //Constructors
        Image[] Dice_Face;
        int[] Dice_Number;
        Random Random_Number;
        int count;


        public GameScreen()
        {
            InitializeComponent();
        }

        private void GameScreen_Load(object sender, EventArgs e)
        {
            //Constructors
            You_Total.Text = "0";
            CPU2_Total.Text = "0";
            CPU3_Total.Text = "0";

            //Image array for dice faces
            Dice_Face = new Image[6];
            Dice_Face[0] = Properties.Resources.Dice1;
            Dice_Face[1] = Properties.Resources.Dice2;
            Dice_Face[2] = Properties.Resources.Dice3;
            Dice_Face[3] = Properties.Resources.Dice4;
            Dice_Face[4] = Properties.Resources.Dice5;
            Dice_Face[5] = Properties.Resources.Dice6;

            //dice face numbers
            Dice_Number = new int[6];

            Random_Number = new Random();
        }

        private void Roll_Button_Click(object sender, EventArgs e)
        {
            Roll();
        }
        private void Roll()
        {
            //constructors
            int YouPoints = 0;
            int CPU2Points = 0;
            int CPU3Points = 0;

            //randomly assign a dice face to invididual dice
            for (int i = 0; i < Dice_Number.Length; i++)
            {
                Dice_Number[i] = Random_Number.Next(0, 6);
                Dice1.Image = Dice_Face[Dice_Number[0]];
                Dice2.Image = Dice_Face[Dice_Number[1]];
                Dice3.Image = Dice_Face[Dice_Number[2]];
                Dice4.Image = Dice_Face[Dice_Number[3]];
                Dice5.Image = Dice_Face[Dice_Number[4]];
                Dice6.Image = Dice_Face[Dice_Number[5]];
            }
            //declare and set seprate scores for each player
            YouPoints = Convert.ToInt32(You_Total.Text) + Dice_Number[0] + Dice_Number[1] + 2;
            CPU2Points = Convert.ToInt32(CPU2_Total.Text) + Dice_Number[2] + Dice_Number[3] + 2;
            CPU3Points = Convert.ToInt32(CPU3_Total.Text) + Dice_Number[4] + Dice_Number[5] + 2;

            You_Total.Text = YouPoints.ToString();
            CPU2_Total.Text = CPU2Points.ToString();
            CPU3_Total.Text = CPU3Points.ToString();
            
            //after 3 rounds, check for winner
            count = count + 1;
            if (count == 3)
            {
                Check(YouPoints, CPU2Points, CPU3Points);
            }
        }
        private void Check(int YouPoints, int CPU2Points, int CPU3Points)
        {
            //check if you won
            if (YouPoints >= CPU2Points)
            {
                if (YouPoints >= CPU3Points)
                {
                    //win screen with score to enter name to home
                    MessageBox.Show("You Win!");
                    this.Hide();
                    NameScreen ns = new NameScreen(YouPoints);
                    ns.Show();
                }
                if (YouPoints < CPU3Points)
                {
                    //lose screen to home
                    MessageBox.Show("You Lose.");
                    this.Hide();
                    HomeScreen hs = new HomeScreen();
                    hs.Show();
                }
            }
            if (YouPoints < CPU2Points)
            {
                //lose screen to home
                MessageBox.Show("You Lose.");
                this.Hide();
                HomeScreen hs = new HomeScreen();
                hs.Show();
            }
        }
    }
}
