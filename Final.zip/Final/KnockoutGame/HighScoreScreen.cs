﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace KnockoutGame
{
    public partial class HighScoreScreen : Form
    {
        public HighScoreScreen()
        {
            InitializeComponent();
        }

        private void ScoreButton_Click(object sender, EventArgs e)
        {
            //show score list
            listBox.Items.Clear();
            List<Player> list = SQLHelper.ViewFromDB();

            foreach (Player x in list)
            {
                listBox.Items.Add(x.Name + " " + x.Score.ToString());
            }
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            //return to home screen
            HomeScreen hs = new HomeScreen();
            this.Hide();
            hs.Show();
        }
    }
}
