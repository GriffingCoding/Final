﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace KnockoutGame
{
    public static class SQLHelper
    {
        public static void InsertIntoDB(string name, int score)
        {
            string connectionString;
            SqlConnection con;
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Final\KnockoutGame\AppDatabase.mdf"";Integrated Security=True; Connect Timeout=30";
            con = new SqlConnection(connectionString);
            con.Open();

            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql;

            sql = "Insert into Scores (name, score) values ('" + name + "', '" + score + "')";

            command = new SqlCommand(sql, con);

            adapter.InsertCommand = new SqlCommand(sql, con);
            adapter.InsertCommand.ExecuteNonQuery();
            command.Dispose();
            con.Close();
        }

        public static List<Player> ViewFromDB()
        {
            string connectionString;
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Final\KnockoutGame\AppDatabase.mdf"";Integrated Security=True; Connect Timeout=30";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM Scores";
            connection.Open();
            SqlDataReader dataReader = command.ExecuteReader();
            List<Player> playerList = new List<Player>();
            while (dataReader.Read())
            {
                Player player = new Player();
                player.Name = dataReader.GetValue(1).ToString();
                player.Score = Convert.ToInt32(dataReader.GetValue(2));
                playerList.Add(player);
            }
            connection.Close();
            dataReader.Close();
            return playerList;

        }
    }

}
