﻿
namespace KnockoutGame
{
    partial class GameScreen
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dice1 = new System.Windows.Forms.PictureBox();
            this.Dice2 = new System.Windows.Forms.PictureBox();
            this.Dice5 = new System.Windows.Forms.PictureBox();
            this.Dice6 = new System.Windows.Forms.PictureBox();
            this.Dice3 = new System.Windows.Forms.PictureBox();
            this.Dice4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Roll_Button = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.CPU3_Total = new System.Windows.Forms.Label();
            this.CPU2_Total = new System.Windows.Forms.Label();
            this.You_Total = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Dice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice4)).BeginInit();
            this.SuspendLayout();
            // 
            // Dice1
            // 
            this.Dice1.Image = global::KnockoutGame.Properties.Resources.Dice1;
            this.Dice1.Location = new System.Drawing.Point(37, 129);
            this.Dice1.Name = "Dice1";
            this.Dice1.Size = new System.Drawing.Size(50, 50);
            this.Dice1.TabIndex = 0;
            this.Dice1.TabStop = false;
            // 
            // Dice2
            // 
            this.Dice2.Image = global::KnockoutGame.Properties.Resources.Dice2;
            this.Dice2.Location = new System.Drawing.Point(93, 129);
            this.Dice2.Name = "Dice2";
            this.Dice2.Size = new System.Drawing.Size(50, 50);
            this.Dice2.TabIndex = 1;
            this.Dice2.TabStop = false;
            // 
            // Dice5
            // 
            this.Dice5.Image = global::KnockoutGame.Properties.Resources.Dice5;
            this.Dice5.Location = new System.Drawing.Point(587, 129);
            this.Dice5.Name = "Dice5";
            this.Dice5.Size = new System.Drawing.Size(50, 50);
            this.Dice5.TabIndex = 2;
            this.Dice5.TabStop = false;
            // 
            // Dice6
            // 
            this.Dice6.Image = global::KnockoutGame.Properties.Resources.Dice6;
            this.Dice6.Location = new System.Drawing.Point(643, 129);
            this.Dice6.Name = "Dice6";
            this.Dice6.Size = new System.Drawing.Size(50, 50);
            this.Dice6.TabIndex = 3;
            this.Dice6.TabStop = false;
            // 
            // Dice3
            // 
            this.Dice3.Image = global::KnockoutGame.Properties.Resources.Dice3;
            this.Dice3.Location = new System.Drawing.Point(317, 129);
            this.Dice3.Name = "Dice3";
            this.Dice3.Size = new System.Drawing.Size(50, 50);
            this.Dice3.TabIndex = 5;
            this.Dice3.TabStop = false;
            // 
            // Dice4
            // 
            this.Dice4.Image = global::KnockoutGame.Properties.Resources.Dice4;
            this.Dice4.Location = new System.Drawing.Point(373, 129);
            this.Dice4.Name = "Dice4";
            this.Dice4.Size = new System.Drawing.Size(50, 50);
            this.Dice4.TabIndex = 6;
            this.Dice4.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(55, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 37);
            this.label1.TabIndex = 7;
            this.label1.Text = "YOU";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(326, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 37);
            this.label2.TabIndex = 8;
            this.label2.Text = "CPU2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(596, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 37);
            this.label3.TabIndex = 9;
            this.label3.Text = "CPU3";
            // 
            // Roll_Button
            // 
            this.Roll_Button.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Roll_Button.Location = new System.Drawing.Point(289, 288);
            this.Roll_Button.Name = "Roll_Button";
            this.Roll_Button.Size = new System.Drawing.Size(161, 54);
            this.Roll_Button.TabIndex = 10;
            this.Roll_Button.Text = "Roll";
            this.Roll_Button.UseVisualStyleBackColor = true;
            this.Roll_Button.Click += new System.EventHandler(this.Roll_Button_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "label4";
            // 
            // CPU3_Total
            // 
            this.CPU3_Total.AutoSize = true;
            this.CPU3_Total.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CPU3_Total.Location = new System.Drawing.Point(634, 182);
            this.CPU3_Total.Name = "CPU3_Total";
            this.CPU3_Total.Size = new System.Drawing.Size(0, 19);
            this.CPU3_Total.TabIndex = 14;
            // 
            // CPU2_Total
            // 
            this.CPU2_Total.AutoSize = true;
            this.CPU2_Total.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CPU2_Total.Location = new System.Drawing.Point(363, 182);
            this.CPU2_Total.Name = "CPU2_Total";
            this.CPU2_Total.Size = new System.Drawing.Size(0, 19);
            this.CPU2_Total.TabIndex = 15;
            // 
            // You_Total
            // 
            this.You_Total.AutoSize = true;
            this.You_Total.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.You_Total.Location = new System.Drawing.Point(84, 182);
            this.You_Total.Name = "You_Total";
            this.You_Total.Size = new System.Drawing.Size(0, 19);
            this.You_Total.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(37, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 19);
            this.label5.TabIndex = 17;
            this.label5.Text = "Total:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(316, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 19);
            this.label6.TabIndex = 18;
            this.label6.Text = "Total:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(587, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 19);
            this.label7.TabIndex = 19;
            this.label7.Text = "Total:";
            // 
            // GameScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 411);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.You_Total);
            this.Controls.Add(this.CPU2_Total);
            this.Controls.Add(this.CPU3_Total);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Roll_Button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Dice4);
            this.Controls.Add(this.Dice3);
            this.Controls.Add(this.Dice6);
            this.Controls.Add(this.Dice5);
            this.Controls.Add(this.Dice2);
            this.Controls.Add(this.Dice1);
            this.MaximumSize = new System.Drawing.Size(750, 450);
            this.MinimumSize = new System.Drawing.Size(750, 450);
            this.Name = "GameScreen";
            this.Text = "KnockOut (Dice Game)";
            this.Load += new System.EventHandler(this.GameScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Dice1;
        private System.Windows.Forms.PictureBox Dice2;
        private System.Windows.Forms.PictureBox Dice5;
        private System.Windows.Forms.PictureBox Dice6;
        private System.Windows.Forms.PictureBox Dice3;
        private System.Windows.Forms.PictureBox Dice4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Roll_Button;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label CPU3_Total;
        private System.Windows.Forms.Label CPU2_Total;
        private System.Windows.Forms.Label You_Total;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

