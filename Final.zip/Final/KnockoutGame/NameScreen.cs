﻿using System;
using System.Windows.Forms;

namespace KnockoutGame
{
    public partial class NameScreen : Form
    {
        public NameScreen(int YouPoints)
        {
            InitializeComponent();
            ScoreLabel.Text = YouPoints.ToString();
        }

        private void EnterButton_Click(object sender, EventArgs e)
        {
            //take player's name and score and send them to Scores table
            int score = Convert.ToInt32(ScoreLabel.Text);
            string name = Name_Input.Text;
            SQLHelper.InsertIntoDB(name, score);
            this.Hide();
            HomeScreen hs = new HomeScreen();
            hs.Show();
        }
    }
}
